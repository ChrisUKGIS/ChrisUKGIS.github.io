# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 09:59:11 2019

@author: GISWork
"""
char = chr(8) # Try 7, as well!
print("hello" + char + "world")
